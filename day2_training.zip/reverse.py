num=123
a=num%10
num=num//10
b=num%10
num=num//10
c=num%10
rev=a*100+b*10+c*1
print("reversed num:",rev)
num=1234567
