name="Mariyam"
print(name)
myName=list(name) #typecasting to list (['M', 'a', 'r', 'i', 'y', 'a', 'm'])
print(myName)